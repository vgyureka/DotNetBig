﻿using System;

namespace Service
{
    public class Class1
    {
    }
}
