﻿using Service.Services;
using System;
using System.Collections.Generic;
using System.ServiceModel.Dispatcher;
using System.Text;

namespace Service.Services
{
    public class TestService : SetupService
    {
    }
    
}
