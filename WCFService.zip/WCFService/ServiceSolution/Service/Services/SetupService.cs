﻿using Client.Shared;
using Client.Shared.Services;
using System;
using System.Collections.Generic;
using System.Text;

namespace Service.Services
{
    public class SetupService : ISetupService
    {
        public List<TestClient> GetData()
        {
            List<TestClient> clientList = new List<TestClient>();
            clientList[0].Id = 1;
            clientList[0].Name = "name1";
            clientList[0].Id = 2;
            clientList[0].Name = "name2";
            return clientList;
        }
    }
}
