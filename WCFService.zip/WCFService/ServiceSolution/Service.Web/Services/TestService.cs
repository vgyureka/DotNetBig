﻿
using Service.Services;

namespace Service.Web
{
    public class TestService : SetupService
    {
    }
}
