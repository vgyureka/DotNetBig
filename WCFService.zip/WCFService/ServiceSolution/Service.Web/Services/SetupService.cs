﻿using Client.Shared;
using Client.Shared.Services;
using System.Collections.Generic;

namespace Service.Web
{
    public class SetupService : ISetupService
    {
        public List<TestClient> GetData()
        {
            List<TestClient> clientList = new List<TestClient>()
        {
            new TestClient(){ Id = 1, Name = "Jessica" },
            new TestClient(){ Id = 2, Name = "Mandy" }
        };
            return clientList;
        }
    }
}
