﻿using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace Client
{
    public static class ServiceClient
    {
        static Dictionary<string, ChannelFactory<ISetupServiceChannel>> _channelFactory =
            new Dictionary<string, ChannelFactory<ISetupServiceChannel>>();


        public static void Call(Action<ISetupServiceChannel> action,
            string endpointName = "TestService")
        {
            ISetupServiceChannel setupServiceChannel = null;
            if (!_channelFactory.ContainsKey(endpointName))
                _channelFactory[endpointName] = new ChannelFactory<ISetupServiceChannel>(endpointName);
            try
            {
                setupServiceChannel = _channelFactory[endpointName].CreateChannel();
               
                using (new OperationContextScope(setupServiceChannel))
                {
                    action(setupServiceChannel);
                }
            }
            finally
            {
                if (setupServiceChannel != null)
                {
                    if (setupServiceChannel.State == CommunicationState.Faulted)
                        setupServiceChannel.Abort();
                    else
                        setupServiceChannel.Close();
                }
            }
        }

    }
}
