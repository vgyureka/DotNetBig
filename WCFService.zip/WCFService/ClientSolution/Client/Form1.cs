﻿using Client.Shared;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class Form1 : Form
    {
        public Form1(List<TestClient> result)
        {
            InitializeComponent();
            textBox1.Text = result[0].Id.ToString();
            textBox2.Text = result[0].Name;
            textBox3.Text = result[1].Name;
            textBox4.Text = result[1].Id.ToString();
        }
    }
}
