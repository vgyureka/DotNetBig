﻿using Client.Shared;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Text;

namespace Client.Shared.Services
{
    [ServiceContract]
    public interface ISetupService
    {
        [OperationContract]
        List<TestClient> GetData();
    }
}
