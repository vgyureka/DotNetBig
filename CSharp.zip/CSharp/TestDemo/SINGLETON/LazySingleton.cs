﻿using System;

namespace ConsoleApplication1
{
    /// <summary>
    /// 1. By default, Lazy<T> objects are thread-safe
    /// </summary>
    public sealed class LazySingleton
    {
        static int instanceCounter = 0;
        private static readonly Lazy<LazySingleton> singleInstance = new Lazy<LazySingleton>(() => new LazySingleton()); //private static Singleton singleInstance = null;
        private LazySingleton()
        {
            instanceCounter++;
            Console.WriteLine("Instances created " + instanceCounter);
        }

        public static LazySingleton SingleInstance
        {
            get
            {
                return singleInstance.Value;
            }
        }
        public  void LogMessage(string message)
        {
            Console.WriteLine("Message " + message);
        }
    }
}
