﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    /// <summary>
    /// Singleton :-
    /// 1.Creational type of design pattern
    /// 2.Ensures a class has only one instance and provides a global point of access to it.
    /// 3.Example:- [log writer class]
    /// 4.single thread-safe object is shared 
    /// -------------------------------
    /// ADVANTAGES OF SINGLETON
    /// -------------------------------
    /// 1.singleton makes sure every client accesses it with no 
    /// deadlock or conflict.
    /// 2.it only allows one instance of a class responsible for 
    /// sharing the resource, across the application.
    /// ------------------------------------------
    /// Singleton class vs. Static methods
    /// ------------------------------------------
    ///1.A Static Class cannot be extended whereas a singleton class can be extended.
    ///2.A Static Class can still have instances (unwanted instances) whereas a singleton class prevents it.
    /// ---------------------
    /// GUIDELINES
    /// ---------------------
    ///1.ONE INSTANCE:-It should creates only one instance of the class,
    /// created at one point only
    ///2.PRIVATE CONSTRUCTOR:-The singleton's class constructors should 
    ///be private so that no class can directly instantiate the 
    ///singleton class.
    ///3.STATIC PROPERTY/METHOD:-There should be a static property/method 
    ///that takes care of singleton class instantiation and that 
    ///property should be shared across applications and is solely 
    ///responsible for returning a singleton instance.
    ///4.SEALED CLASS:-The C# singleton class should be sealed so that it 
    ///could not be inherited by any other class.
    /// </summary>

    //Thread Safety Singleton
    //1.thread-safe.
    //2.The biggest problem with this is performance; performance suffers since a lock is required 
    //every time an instance is requested.
    public sealed class SingletonBasic
    {
        private static int i = 0;
        private SingletonBasic()
        {
            i++;
        }

        private static readonly object padlock = new object();
        private static SingletonBasic instance1 = null;
        public static SingletonBasic Instance
        {
            get
            {
                lock (padlock)
                {
                    if (instance1 == null)
                    {
                        instance1 = new SingletonBasic();
                    }
                    return instance1;
                }
            }
        }

        public void Logwriter()
        {
            Console.WriteLine($"log{i}");
            Console.ReadLine();
        }
    }

    //Thread Safety Singleton using Double Check Locking : - 
    public class SingleTon
    {
        private SingleTon()
        {
            Console.WriteLine("Singleton instance is created in CONSTRUCTOR.");

        }
        private static object lockingObject = new object();
        private static SingleTon singleTonObject;
        public static SingleTon InstanceCreation()
        {
            if (singleTonObject == null)
            {
                lock (lockingObject)
                {
                    if (singleTonObject == null)
                    {
                        singleTonObject = new SingleTon();
                        Console.WriteLine("Singleton instance is created in InstanceCreation method");
                    }
                }
            }
            return singleTonObject;
        }




    }

    //Thread Safe Singleton without using locks and no lazy instantiation
    public sealed class SingletonNoLock
    {
        private static readonly SingletonNoLock instance = new SingletonNoLock();
        static int i = 0;
        static int j = 0;
        // Explicit static constructor to tell C# compiler  
        // not to mark type as beforefieldinit  
        static SingletonNoLock()
        {
            i++;
            Console.WriteLine($"Singleton instance is created in STATIC CONSTRUCTOR.{i}");
        }
        private SingletonNoLock()
        {
            j++;
            Console.WriteLine($"Singleton instance is created in PRIVATE CONSTRUCTOR.{j}");
        }

        public static SingletonNoLock Instance
        {
            get
            {
                return instance;
            }
        }
    }
}
