﻿
using ConsoleApplication1;
using System;
using TestDemo.SINGLETON;

namespace DesignPatterns
{

    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Please choose topic: ");
            Console.WriteLine("1. Basic Singleton");
            Console.WriteLine("2. Thread safe Singleton");
            Console.WriteLine("3. Lazy Singleton");
            Console.WriteLine("4. Session Singleton using property only");
            int choice = Convert.ToInt16(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    Console.WriteLine("Basic Singleton");
                    BasicSingleton();
                    break;

                case 2:
                    Console.WriteLine("Thread safe Singleton");
                    ThreadSafeSingleton();
                    break;

                case 3:
                    Console.WriteLine("Lazy Singleton");
                    LazySingletonDemo();
                    break;

                case 4:
                    Console.WriteLine("Session Singleton using property only");
                    SessionSingleton();
                    break;

                case 5:
                    FactoryMethod();
                    break;

                default: break;
            }

        }

        private static void SessionSingleton()
        {
            SingletonSession.Instance.Authenticated = true;
            SingletonSession.Instance.Environment = "DEV";
        }

        private static void BasicSingleton()
        {
            SingletonBasic obj = SingletonBasic.Instance;
            obj.Logwriter();
            SingletonBasic obj1 = SingletonBasic.Instance;
            obj1.Logwriter();
        }

        private static void ThreadSafeSingleton()
        {
            SingleTon.InstanceCreation();
            SingleTon.InstanceCreation();
            Console.ReadLine();

            var obj = SingletonNoLock.Instance;
            var obj1 = SingletonNoLock.Instance;
            var obj2 = SingletonNoLock.Instance;
            Console.ReadLine();
        }
        private static void LazySingletonDemo()
        {
            LazySingleton obj = LazySingleton.SingleInstance;
            LazySingleton obj1 = LazySingleton.SingleInstance;

            obj.LogMessage("defect1");
            obj1.LogMessage("defect2");
            Console.ReadLine();
        }
        //Factory design pattern
        private static void FactoryMethod()
        {
            int i = 0;
            IGet ObjIntrface = null;
            ObjIntrface = clsFactory.CreateandReturnObj(i + 1);
            string res = ObjIntrface.ConC("First", "Second");
            i++;

        }
    }

}
