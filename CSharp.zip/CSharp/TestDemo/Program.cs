﻿
using ConsoleApplication1;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestDemo.FACTORY;

namespace DesignPatterns
{

    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Please choose topic: ");
            Console.WriteLine("1. Basic Singleton");
            Console.WriteLine("2. Thread safe Singleton");
            Console.WriteLine("3. Lazy Singleton");
            Console.WriteLine("4. Factory Patterns");
            int choice = Convert.ToInt16(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    Console.WriteLine("Basic Singleton");
                    BasicSingleton();
                    break;

                case 2:
                    Console.WriteLine("Thread safe Singleton");
                    ThreadSafeSingleton();
                    break;

                case 3:
                    Console.WriteLine("Lazy Singleton");
                    LazySingletonDemo();
                    break;
                case 4:
                    Console.WriteLine("Factory Pattern");
                    FactoryPattern();
                    break;

                default: break;
            }

        }

        private static void FactoryPattern()
        {
            VehicleFactory factory = new ConcreteVehicleFactory();

            IFactory scooter = factory.GetVehicle("Scooter");
            scooter.Drive(10);

            IFactory bike = factory.GetVehicle("Bike");
            bike.Drive(20);

            Console.ReadKey();
        }

        private static void BasicSingleton()
        {
            SingletonBasic obj =  SingletonBasic.Instance;
            obj.Logwriter();
            SingletonBasic obj1 = SingletonBasic.Instance;
            obj1.Logwriter();
        }

        private static void ThreadSafeSingleton()
        {
            SingleTon.InstanceCreation();
            SingleTon.InstanceCreation();
            Console.ReadLine();

            var obj = SingletonNoLock.Instance;
            var obj1 = SingletonNoLock.Instance;
            var obj2 = SingletonNoLock.Instance;
            Console.ReadLine();
        }
        private static void LazySingletonDemo()
        {
            LazySingleton obj = LazySingleton.SingleInstance;
            LazySingleton obj1 = LazySingleton.SingleInstance;

            obj.LogMessage("defect1");
            obj1.LogMessage("defect2");
            Console.ReadLine();
        }

    }

}
