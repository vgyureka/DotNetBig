﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Csharp_Programs
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Fibonacci.Print();
            Star.Pyramid();
            Star.Print();

        }
      

    }
}
