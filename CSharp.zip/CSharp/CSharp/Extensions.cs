﻿using System;
using System.Linq;

namespace CSharp
{
    public static class Extensions
    {
        public static bool IN(this string sourceString, params string[] argsList)
        {
            argsList.ToList().RemoveAll(x => string.IsNullOrEmpty(x));

            if (!string.IsNullOrEmpty(sourceString) && argsList.Length > 0)
            {
                if (argsList.Any(x => x.Trim().Equals(sourceString.Trim(), StringComparison.CurrentCultureIgnoreCase)))
                    return true;
                else
                    return false;
            }
            return false;
        }

        public static bool AND(this string sourceString, params string[] argsList)
        {
            argsList.ToList().RemoveAll(x => string.IsNullOrEmpty(x));

            if (!string.IsNullOrEmpty(sourceString) && argsList.Length > 0)
            {
                if (argsList.All(x => x.Trim().Equals(sourceString.Trim(), StringComparison.CurrentCultureIgnoreCase)))
                    return true;
                else
                    return false;
            }
            return false;
        }
    }
}
