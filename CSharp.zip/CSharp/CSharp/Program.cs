﻿using CSharp;
using CSharp.POLYMORPHISM.Method_Overriding;
using Microsoft.Practices.Unity.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using Unity;

namespace ConsoleApplication1
{


    public enum LOB
    {
        [Description("AD-Accommodations")]
        [DefaultValue("Accommodations")]
        AD,
        [Description("DS-Disability")]
        [DefaultValue("Disability")]
        DS,
        [Description("GL-General Liability")]
        [DefaultValue("General Liability")]
        GL,
        [Description("FM-Leaves")]
        [DefaultValue("Leaves")]
        FM,
        [Description("LV-Leaves")]
        [DefaultValue("Leaves")]
        LV,
        [Description("PL-Product Liability")]
        [DefaultValue("Product Liability")]
        PL,
        [Description("PR-Property")]
        [DefaultValue("Property")]
        PR,
        [Description("WC-Workers' Compensation")]
        [DefaultValue("Workers' Compensation")]
        WC
    }

    internal class Employee
    {
        public string Name { get; set; }
        public List<string> Skills { get; set; }
    }

    internal class Program
    {
        private static void Main(string[] args)
        {


            Console.WriteLine("Please choose topic: ");
            Console.WriteLine("1. Lazy Singleton");
            Console.WriteLine("2. Extension Methods");
            Console.WriteLine("3. Enums");
            Console.WriteLine("4. Func Delegate");
            Console.WriteLine("5. Action Delegate");
            Console.WriteLine("6. Delegate Examples [Action,func,predicate]");
            Console.WriteLine("7. Duplicate values");
            Console.WriteLine("8. Linq Demo");
            Console.WriteLine("9. Function overloading");
            Console.WriteLine("10. IENUMERATOR DEMO");
            Console.WriteLine("11. Delegates simple example");
            Console.WriteLine("12. singleton simple example");
            Console.WriteLine("13. LINQ - select vs selectMany");
            Console.WriteLine("14. DI_UnityContainer");
            Console.WriteLine("15. Practice");
            Console.WriteLine("16. Polymorphism");
             
            int choice = Convert.ToInt16(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    Console.WriteLine("Lazy Singleton");
                    LazySingletonFunc();
                    break;

                case 2:
                    Console.WriteLine("Extension Methods");
                    ExtensionMethod();
                    break;

                case 3:
                    Console.WriteLine("Enums");
                    Enums();
                    break;
                case 4:
                    DelegatesActionFunc fun = new DelegatesActionFunc();
                    fun.Funcreport();
                    break;
                case 5:
                    DelegatesActionFunc act = new DelegatesActionFunc();
                    act.LoadChanges();
                    act.SaveChanges();
                    break;
                case 6:
                    FuncDelegate.PredicateDemo();
                    FuncDelegate.ActionDemo();
                    FuncDelegate.FuncDemo();
                    break;
                case 7:
                    DuplicateVal();
                    break;
                case 8:
                    LinqDemo();
                    break;
                case 9:
                    //function overloading
                    OverloadTest.func(5);
                    break;
                case 10:
                    //IENUMERATOR DEMO
                    IenumeratorDemo.EnumFunc();
                    break;
                case 11:
                    //delegate simple example
                    DelegatesFunc();
                    break;
                case 12:
                    //Singleton simple example
                    Singleton();
                    break;
                case 13:
                    Select_VS_SelectMany();
                    break;
                case 14:
                    DI_UnityContainer();
                    break;
                case 15:
                    Practice();
                    break;
                case 16:
                    Polymorphism();
                    break;
                default: break;
            }
        }

        private static void Polymorphism()
        {
            DerviedClass obj = new DerviedClass();
            var a = obj.VirtualProp;
            var b = obj.NormalProp;
            var c = obj.NewProp;
            var d = obj.NoOverride;
            Console.WriteLine($"Virtual prop {a}, Normal prop {b}, New prop {c} , No override {d}");
            Console.ReadKey();
        }

        private static void Practice()
        {
            //  Test1 obj = new Test1("");
            // obj.func2();
            //Test1.func2();
        }

        private static void DI_UnityContainer()
        {
            //DI USING UNITY =======
            DI_UnityContainer_Method1();
            //========DI END========
            DI_UnityContainer_Method2();
        }

        private static void DI_UnityContainer_Method2()
        {
            var container = new UnityContainer();
            var section = (UnityConfigurationSection)ConfigurationManager.GetSection("unity");
            section.Containers.Default.Configure(container);

            if (ConfigurationManager.GetSection("unity") != null)
            {
                container.LoadConfiguration();

                Console.WriteLine();
                Console.WriteLine("After loading the config file:");
                EmployeeDI emp = container.Resolve<EmployeeDI>();
            }
        }

        private static void DI_UnityContainer_Method1()
        {
            var container = new UnityContainer();
            container.RegisterType<IDBAccess, SQLDataAccess>();
            EmployeeDI emp = container.Resolve<EmployeeDI>();
        }

        private static void Enums()
        {
            var lobFullName = LOB.DS.ToFullName();
            Console.WriteLine($"Full lob name:- {lobFullName}");
            Console.ReadLine();
            var lobName = LOB.DS.ToName();
            Console.WriteLine($"lob name:- {lobName}");
            Console.ReadLine();
        }

        private static void DuplicateVal()
        {
            List<int> lst = new List<int>();
            Dictionary<int, int> dict = new Dictionary<int, int>();

            int count = 0;
            int[] arr = { 1, 3, 6, 3, 4, 5, 10, 5, 5, 7, 5 };
            var result = arr.OrderBy(x => x).ToList();
            for (int i = 0; i < result.Count; i++)
            {
                if (result[i] == result[i + 1])
                {
                    lst.Add(result[i]);
                    dict.Add(result[i], count);
                    count++;
                }
                else
                {
                    count = 0;
                }
            }
        }

        private static void LinqDemo()
        {
            //union or except or intersect
            int[] numbers = { 1, 2, 3, 4, 5 };
            int[] numbers1 = { 4, 5, 6, 6, 7, 8, 9, 10 };
            //union two list without duplicates
            var nn1 = numbers.Union(numbers1);
            //return common items from 2 lists
            var nn2 = numbers.Intersect(numbers1);
            //return elemets from list1 that r not present in 2nd list
            var nn3 = numbers.Except(numbers1);

            //any or all
            string[] names = { "abc", "zxc", "fgh" };
            string[] namesAll = { "abc", "abc", "abc" };

            var a = names.Any(x => x == "zxc");
            var b = namesAll.All(x => x == "abc");
            var c = names.Contains("abc");

            //first and single
            List<int> lstCount = new List<int> { 10, 20, 30, 40, 50, 60, 70, 80, 90 };
            var result = lstCount.First(x => x > 10);
            var result1 = lstCount.FirstOrDefault();
            var result3 = lstCount.SingleOrDefault(x => x < 20);
            var result2 = lstCount.Single(x => x > 10);


        }

        private static void DelegatesFunc()
        {
            DelegatesActionFunc obj = new DelegatesActionFunc();
            TestDel td = obj.AddNums;
            td(1, 2, 3);
            SayDel sd = DelegatesActionFunc.SayHello;
            sd("VISHU");


        }

        private static void Singleton()
        {
            SingleTonSample.InstanceCreation();
            SingleTonSample.InstanceCreation();
            Console.ReadLine();
            //throw new NotImplementedException();
        }


        //Diff select and select many
        private static void Select_VS_SelectMany()
        {
            List<Employee> employees = new List<Employee>();
            Employee emp1 = new Employee { Name = "Deepak", Skills = new List<string> { "C", "C++", "Java" } };
            Employee emp2 = new Employee { Name = "Karan", Skills = new List<string> { "SQL Server", "C#", "ASP.NET" } };

            Employee emp3 = new Employee { Name = "Lalit", Skills = new List<string> { "C#", "ASP.NET MVC", "Windows Azure", "SQL Server" } };

            employees.Add(emp1);
            employees.Add(emp2);
            employees.Add(emp3);

            // Query using Select()
            IEnumerable<List<String>> resultSelect = employees.Select(e => e.Skills);

            Console.WriteLine("**************** Select ******************");

            // Two foreach loops are required to iterate through the results
            // because the query returns a collection of arrays.
            foreach (List<String> skillList in resultSelect)
            {
                foreach (string skill in skillList)
                {
                    Console.WriteLine(skill);
                }
                Console.WriteLine();
            }

            // Query using SelectMany()
            IEnumerable<string> resultSelectMany = employees.SelectMany(emp => emp.Skills);

            Console.WriteLine("**************** SelectMany ******************");

            // Only one foreach loop is required to iterate through the results 
            // since query returns a one-dimensional collection.
            foreach (string skill in resultSelectMany)
            {
                Console.WriteLine(skill);
            }

            Console.ReadKey();
        }

        //lazy singletion
        private static void LazySingletonFunc()
        {
            LazySingleton obj = LazySingleton.SingleInstance;
            LazySingleton obj1 = LazySingleton.SingleInstance;
            if (obj == obj1)
            {

            }
        }
        //Extensions methods
        private static void ExtensionMethod()
        {

            /// C# extension methods allows developers to extend functionality of an existing type without creating a new derived type,
            /// recompiling, or otherwise modifying the original type.
            ///
            /// An extension method is a static method of a static class,
            /// where the "this" modifier is applied to the first parameter.
            /// The type of the first parameter will be the type that is extended.
            ///
            ///  Benefits of extension methods :-
            ///   1.  Extension methods allow existing classes to be extended without relying on inheritance or having to change the class's source code.
            ///  2.  If the class is sealed than there in no concept of extending its functionality.For this a new concept is introduced, 
            ///    in other words extension methods.

            string str = "Reimbursement";
            if (str.IN("Reimbursement", "Release of Information"))
            {
                // do smthing
            }
        }

    }
}
