﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public static class OverloadTest
    {
        public static void func(Int16 a)
        {
        }
        public static void func(Int32 a)
        {
        }
        public static void func(Int64 a)
        {
        }
    }
   
}
