﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace ConsoleApplication1
{
    public delegate void TestDel(int a, int b, int c);
    public delegate string SayDel(string name);

    public class DelegatesActionFunc
    {
        public void AddNums(int x, int y, int z)
        {
            Console.WriteLine(x + y + z);
        }
        public static string SayHello(string name)
        {
            return "Hello" + name;
        }

        //PRACTICAL EXAMPLE OF ACTION DELEGATE :-
        //RECORD TIME TAKEN BY PARTICULAR LOAD FUNCTIONALITY
        public void LoadChanges()
        {
            //it gets callbacked here
            LoadFunc_Time("Load data with 10 items",()=> LoadFunc1());
            LoadFunc_Time("Load data with n items", () => LoadFunc2(5));
        }
        private void LoadFunc1()
        {
            // LOAD database
            int j = 0;
            for (int i = 0; i < 10; i++)
            {
                j += i;
            }
            var result = j;
        }
        private void LoadFunc2(int range)
        {
            // LOAD database
            int j = 0;
            for (int i = 0; i < range; i++)
            {
                j += i;
            }
            var result = j;
        }
        //Action delegate for load functionality and record time taken by each function
        private void LoadFunc_Time(string functionName , Action act)
        {
            var startTime = Stopwatch.StartNew();
            act();
            startTime.Stop();
            Debug.WriteLine($"Time taken by {functionName} is {startTime.ElapsedMilliseconds}");
        }

        //PRACTICAL EXAMPLE OF ACTION DELEGATE :-
        //HAVE A COMMNON TRY CATCH BLOCKS FOR MULTIPLE FUNCTIONS
        public void SaveChanges()
        {
            string param1 = "", param2 = "", result = "";
            Action<string, Action> save = (ReportName, a) =>
        {
            try
            {
                a();
                Report.Status.Add("Report Saved : " + ReportName);
            }
            catch (Exception ex)
            {
                Report.Errors.Add(ex.Message);
            }
        };
            save("Save Function 1", () => SaveFunction1(param1, param2));
            save("Save Function 2", () => SaveFunction2(param1));
            save("Save Function 3", () => SaveFunction3(param2));

            Func<string, Action, string> saveFunc = (name, b) =>
              {
                  try
                  {
                      b();
                      return "";
                  }
                  catch (Exception ex)
                  {

                      throw;
                  }
              };

        }
        public void Funcreport()
        {
            ReportClass oldReport = new ReportClass();
            oldReport.Status = "old status";
            ReportClass newReport = new ReportClass();
            newReport.Status = "new status";

            FuncDelegate("Report status", oldReport, newReport, x => x.Status);
        }
        private void FuncDelegate<T>(string status, T oldReport, T newReport, Func<T, object> param)
        {
            string oldReportResult = param(oldReport).ToString();
            string newReportResult = param(newReport).ToString();
            if (!string.IsNullOrEmpty(oldReportResult) && !string.IsNullOrEmpty(newReportResult))
                Console.WriteLine($"New report is : {newReportResult}");
            else if (string.IsNullOrEmpty(oldReportResult) && !string.IsNullOrEmpty(newReportResult))
                Console.WriteLine($"No old report , New report is : {newReportResult}");
            else if (!string.IsNullOrEmpty(oldReportResult) && string.IsNullOrEmpty(newReportResult))
                Console.WriteLine($"No new report , old report is : {oldReportResult}");
        }
        private string SaveFunction4(string param1)
        {
            if (param1 == "value")
                return "success";
            else
                return "fail";
        }
        private void SaveFunction3(string param2)
        {
            //TODO
        }

        private void SaveFunction2(string param1)
        {
            //TODO
        }

        private void SaveFunction1(string param1, string param2)
        {
            //TODO
        }


    }

    public static class Report
    {
        public static List<string> Status { get; set; } = new List<string>();
        public static List<string> Errors { get; set; } = new List<string>();
    }
    public class ReportClass
    {
        public string Status { get; set; }
        public string Value { get; set; }
    }
}
