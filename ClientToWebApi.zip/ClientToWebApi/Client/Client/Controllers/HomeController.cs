﻿using App2.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace App2.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        [AllowAnonymous]
        public ActionResult Login()

        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult Login(User obj)
        {
            if (ModelState.IsValid)
            {
                var user = AuthenticateUser(obj);
                var authenticationObj = JsonConvert.DeserializeObject(user);
                if (authenticationObj == null || authenticationObj.ToString() == "failure")
                {
                    ModelState.AddModelError("", "Invalid username or password.");
                }
                else if(authenticationObj.ToString() == "success")
                {
                 //   return View("Dashboard");
                    return RedirectToAction("Dashboard", "Home");
                }
            }

            // If we got this far, something failed, redisplay form
            return View();
        }

        [HttpPost]
        public ActionResult FbLogin(User obj)
        {
            return View();
        }

        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(User obj)
        {
            return View();
        }

        public string AuthenticateUser(User authenticateUserData)
        {
            var url = GetUrl("WebAPI", "AuthenticateUser");

            var authenticateUserJson = JsonConvert.SerializeObject(authenticateUserData);
            var callPackageData = new CallPackage(url, HttpVerbs.Post, authenticateUserJson);
            var authentication = ExecString(callPackageData);
            return authentication;
        }

        public string GetUrl(string host, string key)
        {
            string hostConfig = ConfigurationManager.AppSettings[host];
            string url = hostConfig + key;
            return url;
        }

        public string ExecString(CallPackage callPackage)
        {
            var request = (HttpWebRequest)WebRequest.Create(callPackage.EndPointUrl + callPackage.Parameters);

            request.Method = callPackage.Method.ToString();
            request.ContentLength = 0;
            request.ContentType = callPackage.ContentType;

            if (!string.IsNullOrEmpty(callPackage.PostData) && callPackage.Method == HttpVerbs.Post)
            {
                byte[] bytes = callPackage.Encoding.GetBytes(callPackage.PostData);
                request.ContentLength = bytes.Length;

                using (Stream writeStream = request.GetRequestStream())
                {
                    writeStream.Write(bytes, 0, bytes.Length);
                }
            }

            using (var response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    string message = String.Format("Request failed. Received HTTP {0}", response.StatusCode);
                    throw new ApplicationException(message);
                }
                // grab the response
                StreamReader reader = new StreamReader(response.GetResponseStream());
                //// Read the content.
                string responseFromServer = reader.ReadToEnd();
                responseFromServer.Replace(@"\", "").Trim();

                var responseValue = response.GetResponseStream().ToString();

                return responseFromServer;
            }
        }

        public ActionResult Dashboard()
        {
            return View();
        }

        public ActionResult LogOut()
        {
            //FormsAuthentication.SignOut();
            Session.Abandon(); // it will clear the session at the end of request
            return RedirectToAction("Login", "Home");
        }
    }
}