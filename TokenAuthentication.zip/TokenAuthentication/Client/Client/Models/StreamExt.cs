﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Client.Models
{
    public static class StreamExt
    {
        public static string AsString(this Stream target)
        {
            var result = string.Empty;
            using (var reader = new StreamReader(target))
            {
                result = reader.ReadToEnd();
                reader.Close();
            }
            return result;
        }
    }
}