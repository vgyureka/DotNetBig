﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace App2.Models
{
    public class CallPackage
    {
        public CallPackage()
        {
            Encoding = DefaultEncoding;
            EndPointUrl = string.Empty;
            Parameters = string.Empty;
            Method = HttpVerbs.Get;
            ContentType = "application/json";
            PostData = string.Empty;
        }

        public CallPackage(string endpointUrl)
            : this()
        {
            EndPointUrl = endpointUrl;
        }

        public CallPackage(string endpoint, HttpVerbs method)
            : this(endpoint)
        {
            Method = method;
        }

        public CallPackage(string endpoint, HttpVerbs method, string postData)
            : this(endpoint, method)
        {
            PostData = postData;
        }

        public string EndPointUrl { get; set; }

        public HttpVerbs Method { get; set; }

        public string ContentType { get; set; }

        public string PostData { get; set; }
        public string Parameters { get; set; }
        public Encoding Encoding { get; set; }
        public static Encoding DefaultEncoding = Encoding.GetEncoding("iso-8859-1");


    }
}