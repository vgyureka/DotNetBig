﻿using App2.Models;
using Client.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;

namespace App2.Controllers
{
    public class HomeController : Controller
    {
        string _sessionId;
        string _token;
        // GET: Home
        [AllowAnonymous]
        public ActionResult Login()
        {
            return View();
        }

        #region LOGIN
        [HttpPost]
        public async Task<ActionResult> LoginSession(User obj)
        {
            #region WITHOUT TOKEN
            var responseObj = AuthenticateUser(obj);
            if (responseObj == null || responseObj.status == "failure")
            {
                ModelState.AddModelError("", "Invalid username or password.");
            }
            else if (responseObj.status == "success")
            {
                _sessionId = responseObj.SessionId;
                return RedirectToAction("Dashboard", "Home");
            }
            #endregion

            if (obj.response == null || obj.response == "failure")
            {
                ModelState.AddModelError("", "Invalid username or password.");
            }
            else
            {
                _sessionId = obj.SessionId;
                return RedirectToAction("Dashboard", "Home");
            }
            return View("Login");
        }

        public User AuthenticateUser(User authenticateUserData)
        {
            var url = GetUrl("WebAPI", "AuthenticateUser");
            var authenticateUserJson = JsonConvert.SerializeObject(authenticateUserData);
            var callPackageData = new CallPackage(url, HttpVerbs.Post, authenticateUserJson);
            var rawValue = ExecString(callPackageData);
            var responseValue = JsonConvert.DeserializeObject<User>(rawValue);
            return responseValue;
        }
        #endregion  

        #region OWIN
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> LoginOWIN(User obj, string hidname, string hidpwd)
        {
            obj.UserName = hidname;
            obj.Password = hidpwd;

            if (ModelState.IsValid)
            {
                #region WITH TOKEN
                var tokenObj = TokenData(obj);
                if (tokenObj == null)
                {
                    ModelState.AddModelError("", "Invalid username or password.");
                }
                else if (!string.IsNullOrEmpty(tokenObj.AccessToken))
                {
                    _token = tokenObj.AccessToken;
                    Session["token"] = tokenObj.AccessToken;
                    return RedirectToAction("Dashboard", "Home");
                }
                #endregion
            }

            return View("Login");
        }
        public static ApiTokenEntity TokenData(User authenticateUserData)
        {
            HttpClient client = new HttpClient();
            string Baseurl = ConfigurationManager.AppSettings["TokenWebAPI"];
            client.BaseAddress = new Uri(Baseurl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/x-www-form-urlencoded"));

            HttpResponseMessage response =
            client.PostAsync("token",
          new StringContent(string.Format("grant_type=password&username={0}&password={1}",
            HttpUtility.UrlEncode(authenticateUserData.UserName),
            HttpUtility.UrlEncode(authenticateUserData.Password)), Encoding.UTF8,
            "application/x-www-form-urlencoded")).Result;

            if (response.IsSuccessStatusCode)
            {
                var tokenResponse = response.Content.ReadAsStringAsync().Result;
                var responseValue = JsonConvert.DeserializeObject<ApiTokenEntity>(tokenResponse);
                return responseValue;
            }
            else
            {
                return null;
            }
        }
        public async Task<ActionResult> GetAll()
        {
            HttpClient client = new HttpClient();
            string path = "api/values/getAll";
            string token = Session["token"]?.ToString();

            string Baseurl = ConfigurationManager.AppSettings["TokenWebAPI"];
            client.BaseAddress = new Uri(Baseurl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/x-www-form-urlencoded"));
            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
            HttpResponseMessage response = client.GetAsync(path).Result;

            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                var responseValue = JsonConvert.DeserializeObject<IEnumerable<string>>(result);
                ViewBag.result = responseValue;
            }
            else
            {
                ViewBag.Error = "Error :" + response.StatusCode;
            }
            return View();
        }

        public async Task<ActionResult> GetAuthenticate()
        {
            HttpClient client = new HttpClient();
            string path = "api/values/authenticate";
            string token = Session["token"]?.ToString();

            string Baseurl = ConfigurationManager.AppSettings["TokenWebAPI"];
            client.BaseAddress = new Uri(Baseurl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/x-www-form-urlencoded"));
            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
            HttpResponseMessage response = client.GetAsync(path).Result;

            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                var responseValue = JsonConvert.DeserializeObject<IEnumerable<string>>(result);
                ViewBag.result = responseValue;
            }
            else
            {
                ViewBag.Error = "Error :" + response.StatusCode;
            }
            return View("GetAll");
        }

        public async Task<ActionResult> GetAuthorize()
        {
            HttpClient client = new HttpClient();
            string path = "api/values/authorize";
            string token = Session["token"]?.ToString();

            string Baseurl = ConfigurationManager.AppSettings["TokenWebAPI"];
            client.BaseAddress = new Uri(Baseurl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/x-www-form-urlencoded"));
            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
            HttpResponseMessage response = client.GetAsync(path).Result;

            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                var responseValue = JsonConvert.DeserializeObject<IEnumerable<string>>(result);
                ViewBag.result = responseValue;
            }
            else
            {
                ViewBag.Error = "Error :" + response.StatusCode;
            }
            return View("GetAll");
        }
        #endregion

        #region JWT
        public string AuthenticateUserJWT(User authenticateUserData)
        {
            var url = GetUrl("WebAPI", "api/login");
            var authenticateUserJson = JsonConvert.SerializeObject(authenticateUserData);
            var callPackageData = new CallPackage(url, HttpVerbs.Post, authenticateUserJson);
            var rawValue = ExecStringJWT(callPackageData);
            var responseValue = JsonConvert.DeserializeObject<string>(rawValue);
            return responseValue;
        }
        [HttpPost]
        public async Task<ActionResult> LoginJWT(User obj, string hidJWTname, string hidJWTpwd)
        {
            obj.UserName = hidJWTname;
            obj.Password = hidJWTpwd;
            Session["nameJWT"] = hidJWTname;

            #region WITHOUT TOKEN
            var responseObj = AuthenticateUserJWT(obj);
            if (responseObj == null || responseObj == "ERROR")
            {
                ModelState.AddModelError("", "Invalid username or password.");
            }
            else
            {
                Session["tokenJWT"] = responseObj;
                return RedirectToAction("DashboardJWT", "Home");
            }
            #endregion

            return View("Login");
        }
        public async Task<ActionResult> GetAuthenticateJWT()
        {
            HttpClient client = new HttpClient();
            string username = Session["nameJWT"].ToString();
            string token = Session["tokenJWT"].ToString();

            string parameters = $"/?username={username}&token={token}";
            string path = "api/Validate" + parameters;

            string Baseurl = ConfigurationManager.AppSettings["TokenWebAPI"];
            client.BaseAddress = new Uri(Baseurl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/x-www-form-urlencoded"));

            HttpResponseMessage response = client.GetAsync(path).Result;

            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                var responseValue = JsonConvert.DeserializeObject<IEnumerable<string>>(result);
                ViewBag.resultJWT = "Successfully validated !! " + responseValue;
            }
            else
            {
                ViewBag.Error = "Error :" + response.StatusCode;
            }
            return View("GetAll");
        }
        public ActionResult DashboardJWT()
        {
            return View();
        }

        public string ExecStringJWT(CallPackage callPackage)
        {
            var request = (HttpWebRequest)WebRequest.Create(callPackage.EndPointUrl + callPackage.Parameters);

            request.Method = callPackage.Method.ToString();
            request.ContentLength = 0;
            request.ContentType = callPackage.ContentType;

            if (!string.IsNullOrEmpty(callPackage.PostData) && callPackage.Method == HttpVerbs.Post)
            {
                byte[] bytes = callPackage.Encoding.GetBytes(callPackage.PostData);
                request.ContentLength = bytes.Length;

                using (Stream writeStream = request.GetRequestStream())
                {
                    writeStream.Write(bytes, 0, bytes.Length);
                }
            }

            using (var response = (HttpWebResponse)request.GetResponse())
            {
                var responseValue = response.GetResponseStream().AsString();
                return responseValue;

            }
        }
        #endregion

        #region COMMON
        public string GetUrl(string host, string key)
        {
            string hostConfig = ConfigurationManager.AppSettings[host];
            string url = hostConfig + key;
            return url;
        }

        public string ExecString(CallPackage callPackage)
        {
            var request = (HttpWebRequest)WebRequest.Create(callPackage.EndPointUrl + callPackage.Parameters);

            request.Method = callPackage.Method.ToString();
            request.ContentLength = 0;
            request.ContentType = callPackage.ContentType;

            if (!string.IsNullOrEmpty(callPackage.PostData) && callPackage.Method == HttpVerbs.Post)
            {
                byte[] bytes = callPackage.Encoding.GetBytes(callPackage.PostData);
                request.ContentLength = bytes.Length;

                using (Stream writeStream = request.GetRequestStream())
                {
                    writeStream.Write(bytes, 0, bytes.Length);
                }
            }

            using (var response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    string message = String.Format("Request failed. Received HTTP {0}", response.StatusCode);
                    return message;
                    throw new ApplicationException(message);
                }
                // grab the response
                var responseValue = response.GetResponseStream().AsString();
                return responseValue;

            }
        }

        public ActionResult Dashboard()
        {
            return View();
        }

        #endregion

        #region OTHERS
        public ActionResult LogOut()
        {
            //FormsAuthentication.SignOut();
            Session.Abandon(); // it will clear the session at the end of request
            return RedirectToAction("Login", "Home");
        }
        public ActionResult Register()
        {
            return View();
        }
        #endregion

    }
}