﻿using App2.Models;
using Client.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;

namespace App2.Controllers
{
    public class HomeController : Controller
    {
        string _sessionId;
        string _token;
        // GET: Home
        [AllowAnonymous]
        public ActionResult Login()

        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(User obj)
        {
            
            if (ModelState.IsValid)
            {
                //ClientData(obj);
                #region WITHOUT TOKEN
                var tokenObj = TokenData(obj); 
                if (tokenObj == null)
                {
                    ModelState.AddModelError("", "Invalid username or password.");
                }
                else if (!string.IsNullOrEmpty(tokenObj.AccessToken))
                {
                    _token = tokenObj.AccessToken;
                    return RedirectToAction("Dashboard", "Home");
                }
                #endregion
               
                #region WITHOUT TOKEN
                var responseObj = AuthenticateUser(obj);
                if (responseObj == null || responseObj.status == "failure")
                {
                    ModelState.AddModelError("", "Invalid username or password.");
                }
                else if (responseObj.status == "success")
                {
                    _sessionId = responseObj.SessionId;
                    return RedirectToAction("Dashboard", "Home");
                }
                #endregion
            }

            // If we got this far, something failed, redisplay form
            return View();
        }

        [HttpPost]
        public ActionResult FbLogin(User obj)
        {
            return View();
        }

        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(User obj)
        {
            return View();
        }

        public User AuthenticateUser(User authenticateUserData)
        {
            var url = GetUrl("WebAPI", "AuthenticateUser");

            var authenticateUserJson = JsonConvert.SerializeObject(authenticateUserData);
            var callPackageData = new CallPackage(url, HttpVerbs.Post, authenticateUserJson);
            //var authentication = ExecString(callPackageData);
            var rawValue = ExecString(callPackageData);
            var responseValue = JsonConvert.DeserializeObject<User>(rawValue);
            return responseValue;
        }

        public string GetUrl(string host, string key)
        {
            string hostConfig = ConfigurationManager.AppSettings[host];
            string url = hostConfig + key;
            return url;
        }

        public string ExecString(CallPackage callPackage)
        {
            var request = (HttpWebRequest)WebRequest.Create(callPackage.EndPointUrl + callPackage.Parameters);

            request.Method = callPackage.Method.ToString();
            request.ContentLength = 0;
            request.ContentType = callPackage.ContentType;

            if (!string.IsNullOrEmpty(callPackage.PostData) && callPackage.Method == HttpVerbs.Post)
            {
                byte[] bytes = callPackage.Encoding.GetBytes(callPackage.PostData);
                request.ContentLength = bytes.Length;

                using (Stream writeStream = request.GetRequestStream())
                {
                    writeStream.Write(bytes, 0, bytes.Length);
                }
            }

            using (var response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    string message = String.Format("Request failed. Received HTTP {0}", response.StatusCode);
                    throw new ApplicationException(message);
                }
                // grab the response
                var responseValue = response.GetResponseStream().AsString();
                return responseValue;

                #region COMMENTED
                // grab the response
                //StreamReader reader = new StreamReader(response.GetResponseStream());
                ////// Read the content.
                //string responseFromServer = reader.ReadToEnd();
                //responseFromServer.Replace(@"\", "").Trim();
                //var responseValue = response.GetResponseStream().ToString();
                //return responseFromServer;
                #endregion
            }
        }

        static string PostData(string token, List<KeyValuePair<string, string>> lsPostContent)
        {
            string response = String.Empty;
            try
            {
                using (var client = new HttpClient())
                {
                    FormUrlEncodedContent cont = new FormUrlEncodedContent(lsPostContent);
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                    var resp = client.PostAsync("https://localhost:61086/api/<your API controller>/", cont);

                    resp.Wait(TimeSpan.FromSeconds(10));

                    if (resp.IsCompleted)
                    {
                        if (resp.Result.StatusCode == HttpStatusCode.Unauthorized)
                        {
                            Console.WriteLine("Authorization failed. Token expired or invalid.");
                        }
                        else
                        {
                            response = resp.Result.Content.ReadAsStringAsync().Result;
                            Console.WriteLine(response);
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return response;
        }

        public ActionResult Dashboard()
        {
            HttpClient client = new HttpClient();
            string path = "api/data/authenticate";
            string path1 = "api/values/getAll";

            string Baseurl = ConfigurationManager.AppSettings["TokenWebAPI"];
            client.BaseAddress = new Uri(Baseurl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/x-www-form-urlencoded"));
            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + _token);
             HttpResponseMessage response = client.GetAsync(path).Result;
          

            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                var responseValue = JsonConvert.DeserializeObject<IEnumerable<string>>(result);
            }
            else
            {
               
            }
            return View();
        }

        public ActionResult LogOut()
        {
            //FormsAuthentication.SignOut();
            Session.Abandon(); // it will clear the session at the end of request
            return RedirectToAction("Login", "Home");
        }

        public static async void ClientData(User authenticateUserData)
        {
            // string Baseurl = "http://localhost:55503/";
            string Baseurl = ConfigurationManager.AppSettings["WebAPI"];

            //   List<LoginModel> EmpInfo = new List<LoginModel>();

            using (var client = new HttpClient())
            {
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));


                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                //HttpResponseMessage Res = await client.GetAsync("api/LoginPost");
                //var stringContent = new StringContent(model.ToString());
                // var values = new Dictionary<string, string>();
                //  values.Add("ThisIs", "Annoying");

                string json = JsonConvert.SerializeObject(authenticateUserData, Formatting.Indented);
                var buffer = System.Text.Encoding.UTF8.GetBytes(json);
                var byteContent = new ByteArrayContent(buffer);
                //  byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                client.DefaultRequestHeaders.Add("Authorization", byteContent.ToString());
                // 

                //vg
                //client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", byteContent.ToString());
                //client.DefaultRequestHeaders.Add("Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes($"{"user"}:{"pwd"}")));


                //vg

                //client.DefaultRequestHeaders.Add("Authorization",buffer.ToString());

                //client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);

                //  var httpResponce = Helper.Client.PostAsync(path, byteContent).Result;

                HttpResponseMessage Res = await client.PostAsync("api/AuthenticateUser", byteContent);

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var EmpResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    // EmpInfo = JsonConvert.DeserializeObject<List<LoginModel>>(EmpResponse);

                }
            }
        }

        public static  ApiTokenEntity TokenData(User authenticateUserData)
        {
            HttpClient client = new HttpClient();
            string Baseurl = ConfigurationManager.AppSettings["TokenWebAPI"];
            client.BaseAddress = new Uri(Baseurl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/x-www-form-urlencoded"));

            #region COMMENTED
            //JObject oJsonObject = new JObject();
            //oJsonObject.Add("grant_type", "password");
            //oJsonObject.Add("username", "admin");
            //oJsonObject.Add("password", "admin");
            //  string result = GetQueryString(oJsonObject);
            //StringContent payload = new StringContent(result);
            //HttpResponseMessage response = client.PostAsync("token", payload).Result;
            #endregion

            HttpResponseMessage response =
            client.PostAsync("token",
          new StringContent(string.Format("grant_type=password&username={0}&password={1}",
            HttpUtility.UrlEncode(authenticateUserData.UserName),
            HttpUtility.UrlEncode(authenticateUserData.Password)), Encoding.UTF8,
            "application/x-www-form-urlencoded")).Result;

            if (response.IsSuccessStatusCode)
            {
                //ApiTokenEntity _entity = response.Content.ReadAsAsync<ApiTokenEntity>().Result;
                //  return _entity;
                var tokenResponse = response.Content.ReadAsStringAsync().Result;
                var responseValue = JsonConvert.DeserializeObject<ApiTokenEntity>(tokenResponse);
                return responseValue;
            }
            else
            {
                  return null;
            }
        }

        private static string GetQueryString(JObject obj)
        {
            var properties = from p in obj.GetType().GetProperties()
                             where p.GetValue(obj, null) != null
                             select p.Name + "=" + HttpUtility.UrlEncode(p.GetValue(obj, null).ToString());

            return String.Join("&", properties.ToArray());
        }
    }
}