﻿using App2.Models;
using Client.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace Client.Controllers
{
    public class TestController : Controller
    {
        // GET: Test
        public ActionResult Index()
        {
            return View();
        }

        public static async void ClientData(User authenticateUserData)
        {
            // string Baseurl = "http://localhost:55503/";
            string Baseurl = ConfigurationManager.AppSettings["WebAPI"];

            //   List<LoginModel> EmpInfo = new List<LoginModel>();

            using (var client = new HttpClient())
            {
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));


                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                //HttpResponseMessage Res = await client.GetAsync("api/LoginPost");
                //var stringContent = new StringContent(model.ToString());
                // var values = new Dictionary<string, string>();
                //  values.Add("ThisIs", "Annoying");

                string json = JsonConvert.SerializeObject(authenticateUserData, Formatting.Indented);
                var buffer = System.Text.Encoding.UTF8.GetBytes(json);
                var byteContent = new ByteArrayContent(buffer);
                //  byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                client.DefaultRequestHeaders.Add("Authorization", byteContent.ToString());
                // 

                //vg
                //client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", byteContent.ToString());
                //client.DefaultRequestHeaders.Add("Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes($"{"user"}:{"pwd"}")));


                //vg

                //client.DefaultRequestHeaders.Add("Authorization",buffer.ToString());

                //client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);

                //  var httpResponce = Helper.Client.PostAsync(path, byteContent).Result;

                HttpResponseMessage Res = await client.PostAsync("api/AuthenticateUser", byteContent);

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var EmpResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    // EmpInfo = JsonConvert.DeserializeObject<List<LoginModel>>(EmpResponse);

                }
            }
        }

        public static ApiTokenEntity TokenData(User authenticateUserData)
        {
            HttpClient client = new HttpClient();
            string Baseurl = ConfigurationManager.AppSettings["TokenWebAPI"];
            client.BaseAddress = new Uri(Baseurl);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/x-www-form-urlencoded"));

            #region COMMENTED
            //JObject oJsonObject = new JObject();
            //oJsonObject.Add("grant_type", "password");
            //oJsonObject.Add("username", "admin");
            //oJsonObject.Add("password", "admin");
            //  string result = GetQueryString(oJsonObject);
            //StringContent payload = new StringContent(result);
            //HttpResponseMessage response = client.PostAsync("token", payload).Result;
            #endregion

            HttpResponseMessage response =
            client.PostAsync("token",
          new StringContent(string.Format("grant_type=password&username={0}&password={1}",
            HttpUtility.UrlEncode(authenticateUserData.UserName),
            HttpUtility.UrlEncode(authenticateUserData.Password)), Encoding.UTF8,
            "application/x-www-form-urlencoded")).Result;

            if (response.IsSuccessStatusCode)
            {
                //ApiTokenEntity _entity = response.Content.ReadAsAsync<ApiTokenEntity>().Result;
                //  return _entity;
                var tokenResponse = response.Content.ReadAsStringAsync().Result;
                var responseValue = JsonConvert.DeserializeObject<ApiTokenEntity>(tokenResponse);
                return responseValue;
            }
            else
            {
                return null;
            }
        }

        private static string GetQueryString(JObject obj)
        {
            var properties = from p in obj.GetType().GetProperties()
                             where p.GetValue(obj, null) != null
                             select p.Name + "=" + HttpUtility.UrlEncode(p.GetValue(obj, null).ToString());

            return String.Join("&", properties.ToArray());
        }

        public string ExecString(CallPackage callPackage)
        {
            var request = (HttpWebRequest)WebRequest.Create(callPackage.EndPointUrl + callPackage.Parameters);

            request.Method = callPackage.Method.ToString();
            request.ContentLength = 0;
            request.ContentType = callPackage.ContentType;

            if (!string.IsNullOrEmpty(callPackage.PostData) && callPackage.Method == HttpVerbs.Post)
            {
                byte[] bytes = callPackage.Encoding.GetBytes(callPackage.PostData);
                request.ContentLength = bytes.Length;

                using (Stream writeStream = request.GetRequestStream())
                {
                    writeStream.Write(bytes, 0, bytes.Length);
                }
            }

            using (var response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    string message = String.Format("Request failed. Received HTTP {0}", response.StatusCode);
                    throw new ApplicationException(message);
                }
                // grab the response
                var responseValue = response.GetResponseStream().AsString();
                return responseValue;

                #region COMMENTED
                // grab the response
                //StreamReader reader = new StreamReader(response.GetResponseStream());
                ////// Read the content.
                //string responseFromServer = reader.ReadToEnd();
                //responseFromServer.Replace(@"\", "").Trim();
                //var responseValue = response.GetResponseStream().ToString();
                //return responseFromServer;
                #endregion
            }
        }

        static string PostData(string token, List<KeyValuePair<string, string>> lsPostContent)
        {
            string response = String.Empty;
            try
            {
                using (var client = new HttpClient())
                {
                    FormUrlEncodedContent cont = new FormUrlEncodedContent(lsPostContent);
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                    var resp = client.PostAsync("https://localhost:61086/api/<your API controller>/", cont);

                    resp.Wait(TimeSpan.FromSeconds(10));

                    if (resp.IsCompleted)
                    {
                        if (resp.Result.StatusCode == HttpStatusCode.Unauthorized)
                        {
                            Console.WriteLine("Authorization failed. Token expired or invalid.");
                        }
                        else
                        {
                            response = resp.Result.Content.ReadAsStringAsync().Result;
                            Console.WriteLine(response);
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return response;
        }
    }
}