﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using webApiTokenAuthentication.Models;

namespace webApiTokenAuthentication.Repositories
{
    public class UserRepository
    {
        public List<User> TestUsers;
        public UserRepository()
        {
            TestUsers = new List<User>();
            TestUsers.Add(new User() { UserName = "test1", Password = "pass1" });
            TestUsers.Add(new User() { UserName = "test2", Password = "pass2" });
            TestUsers.Add(new User() { UserName = "admin", Password = "pwd" });
        }
        public User GetUser(string username)
        {
            try
            {
                return TestUsers.First(user => user.UserName.Equals(username));
            }
            catch
            {
                return null;
            }
        }

        public User ValidateUser(string username,string password)
        {
            try
            {
                return TestUsers.First(user => user.UserName.Equals(username) &&
                user.Password.Equals(password));
            }
            catch
            {
                return null;
            }
        }
    }
}