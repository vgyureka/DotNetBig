﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Web;

namespace webApiTokenAuthentication.Models
{
    /// <summary>
    /// This will take care of both the creation and the validation of tokens.
    /// To use the JWT functionality, you must install a package that offers access to JWT :-
    /// System.IdentityModel.Tokens.Jwt package
    /// 1. The first thing to create in the new TokenManager class is a field 
    /// called Secret that is going to act as the secret key for the tokens. 
    /// </summary>
    public class TokenManager
    {
        //public static string Secret = "XCAP05H6LoKvbRRa/QkqLNMI7cOHguaRyHzyg7n5qEkGjQmtBhz4SzYh4Fqwjyi3KJHlSXKPwVu2+bXr6CtpgQ==";
        public static string Secret = SecretKey();
        public static string GenerateToken(string username)
        {
            byte[] key = Convert.FromBase64String(Secret);
            //1. create a SymmetricSecurityKey object by using the HMACSHA256 secret 
            SymmetricSecurityKey securityKey = new SymmetricSecurityKey(key);
            //2.create descriptor object. This represents the main content of the JWT, 
            //such as the claims, the expiration date and the signing information.
            SecurityTokenDescriptor descriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] {
                      new Claim(ClaimTypes.Name, username)}),
                Expires = DateTime.UtcNow.AddMinutes(30),
                SigningCredentials = new SigningCredentials(securityKey,
                SecurityAlgorithms.HmacSha256Signature)
            };
            //3.Then, the token is created and a string version of it is returned.
            JwtSecurityTokenHandler handler = new JwtSecurityTokenHandler();
            JwtSecurityToken token = handler.CreateJwtSecurityToken(descriptor);
            return handler.WriteToken(token);
        }

        public static string SecretKey()
        {
            HMACSHA256 hmac = new HMACSHA256();
            string key = Convert.ToBase64String(hmac.Key);
            return key;
        }
    }
}