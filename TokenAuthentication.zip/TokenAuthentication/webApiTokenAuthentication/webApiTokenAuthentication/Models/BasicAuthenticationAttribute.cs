﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace WebApi.Models
{
    public class BasicAuthenticationAttribute : AuthorizationFilterAttribute
    {
        public override void OnAuthorization(HttpActionContext actionContext)
        {
            if (actionContext.Request.Headers.Authorization == null)
            {
                actionContext.Response = actionContext.Request
                    .CreateResponse(HttpStatusCode.Unauthorized);
            }
            else
            {
                string authenticationToken = actionContext.Request.Headers
                                            .Authorization.Parameter;
                string decodedAuthenticationToken = Encoding.UTF8.GetString(
                    Convert.FromBase64String(authenticationToken));
                string[] usernamePasswordArray = decodedAuthenticationToken.Split(':');
                string username = usernamePasswordArray[0];
                string password = usernamePasswordArray[1];

                if (username == "admin" && password == "admin")
                {
                    Thread.CurrentPrincipal = new GenericPrincipal(
                        new GenericIdentity(username), null);
                }
                else
                {
                    actionContext.Response = actionContext.Request
                        .CreateResponse(HttpStatusCode.Unauthorized);
                }
            }
        }

        //public override void OnAuthorization(HttpActionContext actionContext)
        //{
        //    //vg
        //    //Res.Content.ReadAsStringAsync().Result;
        //    //var result = actionContext.Request.Content.Headers.ContentEncoding;
        //    var a = actionContext.RequestContext.RouteData.Values;
        //    var a1 = actionContext.RequestContext.RouteData.Route;
        //    var a2 = actionContext.RequestContext.Principal.Identity;
        //    var a3 = actionContext.RequestContext.Url.Request.Content.ReadAsStringAsync();
        //    var headerData = actionContext.Request.Headers.Where(x => x.Key == "Authorization").Single().Value;

        //    //vg
        //    string authHeader = null;
        //    var auth = actionContext.Request.Headers.Authorization;
        //    if (auth != null && auth.Scheme == "Basic")
        //        authHeader = auth.Parameter;

        //    if (string.IsNullOrEmpty(authHeader))
        //    //    return null;

        //    authHeader = Encoding.Default.GetString(Convert.FromBase64String(authHeader));

        //    var tokens = authHeader.Split(':');
        //  //  if (tokens.Length < 2)
        //       // return null;

        //  //  return new BasicAuthenticationIdentity(tokens[0], tokens[1]);
        //}
    }
}