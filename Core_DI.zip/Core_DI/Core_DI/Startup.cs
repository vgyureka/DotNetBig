﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Core_DI.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Core_DI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();
            ///TRANSIENT [LASTING FOR SHORT TIME ]
            /// [The Transient services are always created new, each time the service is requested.]
            /// Always return new instance
            services.AddTransient<ITransientService, SomeService>();
            /// SCOPED :
            ///1. The Services with scoped lifetime are created only once per each request(scope).
            ///2. a new instance is created per request, and the instance is reused within that request.
            services.AddScoped<IScopedService, SomeService>();
            ///SINGLETON : 
            ///1. Single Instance of the service is created when it was requested for the first time.
            ///2. After that for every subsequent request, it will use the same instance.
            ///3. The new request does not create the new instance of the service but reuses the instance already created.
            services.AddSingleton<ISingletonService, SomeService>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
