﻿using System;
using System.Collections.Generic;

namespace Core_DI.Models
{
//    Transient
//    The Transient services are always created new, each time the service is requested.
    public interface ITransientService
    {
        Guid GetID();
    }

    public interface IScopedService
    {
        Guid GetID();
    }

    public interface ISingletonService
    {
        Guid GetID();
    }

    public interface IService
    {
        string GetAny();
    }
    //public interface IUserRepository
    //{
    //    List<User> GetAll();
    //}
    //public class UserRepository : IUserRepository
    //{
    //    public List<User> GetAll()
    //    {
    //        return new List<User>()
    //    {
    //        new User()
    //        {
    //            FirstName = "Ash",
    //            LastName = "Ketchum",
    //            Username = "User1"
    //        },
    //        new User()
    //        {
    //            FirstName = "Brock",
    //            LastName = "Harrison",
    //            Username = "User1"
    //        },
    //        new User()
    //        {
    //            FirstName = "Misty",
    //            LastName = "Dsouza",
    //            Username = "User3"
    //        }
    //    };
    //    }
    //}
}
